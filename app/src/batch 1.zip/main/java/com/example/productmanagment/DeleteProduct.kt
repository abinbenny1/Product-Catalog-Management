package com.example.productmanagment

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class DeleteProduct : AppCompatActivity() {

    private lateinit var dbHelper: ProductDatabaseHelper
    private lateinit var productNameInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_delete_product)

        dbHelper = ProductDatabaseHelper(this)

        productNameInput = findViewById(R.id.productname)

        val deleteButton = findViewById<Button>(R.id.delete)
        deleteButton.setOnClickListener {
            val productName = productNameInput.text.toString()

            if (productName.isNotEmpty()) {
                dbHelper.deleteProduct(productName)
                Toast.makeText(this, "Product deleted", Toast.LENGTH_SHORT).show()

                val intent = Intent(this, ViewProducts::class.java)
                startActivity(intent)
            } else {
                Toast.makeText(this, "Please enter a product name", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
