package com.example.productmanagment

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class UpdateProduct : AppCompatActivity() {

    private lateinit var dbHelper: ProductDatabaseHelper
    private lateinit var productNameInput: EditText
    private lateinit var productPriceInput: EditText
    private lateinit var productQuantityInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_update_product)

        dbHelper = ProductDatabaseHelper(this)

        productNameInput = findViewById(R.id.productname)
        productPriceInput = findViewById(R.id.price)
        productQuantityInput = findViewById(R.id.quantity)

        val intent = intent
        val productName = intent.getStringExtra("product_name")
        val productPrice = intent.getIntExtra("product_price", 0)
        val productQuantity = intent.getIntExtra("product_quantity", 0)

        productNameInput.setText(productName)
        productPriceInput.setText(productPrice.toString())
        productQuantityInput.setText(productQuantity.toString())

        val updateButton = findViewById<Button>(R.id.update)
        updateButton.setOnClickListener {
            val updatedName = productNameInput.text.toString()
            val updatedPrice = productPriceInput.text.toString().toInt()
            val updatedQuantity = productQuantityInput.text.toString().toInt()

            if (updatedName.isNotEmpty()) {
                val updatedProduct = Product(updatedName, updatedPrice, updatedQuantity)
                dbHelper.updateProduct(updatedProduct)
                Toast.makeText(this, "Product updated", Toast.LENGTH_SHORT).show()

                val intent = Intent(this, ViewProducts::class.java)
                startActivity(intent)
            } else {
                Toast.makeText(this, "Please enter product details", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
