package com.example.productmanagment

data class Product(val name: String, val price: Int, val quantity: Int)
